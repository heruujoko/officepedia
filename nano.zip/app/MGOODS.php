<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MGOODS extends Model
{
    protected $table = 'mgoods';
}
